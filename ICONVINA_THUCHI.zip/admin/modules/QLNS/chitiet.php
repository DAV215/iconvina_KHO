<?php 
    include('QLNS/thongke.php');
    echo $id;
?>