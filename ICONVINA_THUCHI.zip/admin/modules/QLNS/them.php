thêm
<div class="userForm">
    <div class="avtGrid">
        <img src="../asset/media/base/logo/ICONVINA_logo.png" alt="">
        <button>Upload</button>
    </div>
    <div class="inforForm">
aaaaaaaaaaaaaa
    </div>
</div>