<link rel="stylesheet" href="../asset/css/admin/menuTop.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
    integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
<nav class="menu">
    <a href="admin.php?logout=true"><i class="fa-regular fa-bell"></i></a>
    <a href="admin.php?logout=true"><i class="fa-solid fa-power-off"></i></a>
    <h1>
        <?php 
        if($_SESSION['admin']){
            echo 'ADMIN';
        }else echo $_SESSION['userINFO']['fullname']; ?>
    </h1>
</nav>