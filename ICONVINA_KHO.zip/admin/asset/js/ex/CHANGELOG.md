## 1.1.2 (2019-02-06)

Changes:
	- Updated dependencies
    - Switched to yarn
    - merged PRs: https://github.com/rainabba/jquery-table2excel/pull/103,
         https://github.com/rainabba/jquery-table2excel/pull/110 and manually
         implemented changes from https://github.com/rainabba/jquery-table2excel/pull/108
    - Added 'serve' task for manual testing of library (rebuilds dist also)

## 1.1.1 (2017-04-28)

Changes:
	- Update to README.md and packaging

## 1.1.0 (2017-04-28)

Features:
	- Include td and th
	- Update dev dependencies and CONTRIBUTING.md
	- Cleanup repo tags/releases
